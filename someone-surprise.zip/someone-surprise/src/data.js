// ✏️ EDIT DI SINI: foto, caption, isi surat, ramalan, kuis.
export const photos = [
  {src:'/photos/foto1.svg',caption:'Caption foto 1'},
  {src:'/photos/foto2.svg',caption:'Caption foto 2'},
  {src:'/photos/foto3.svg',caption:'Caption foto 3'},
  {src:'/photos/foto4.svg',caption:'Caption foto 4'},
  {src:'/photos/foto5.svg',caption:'Caption foto 5'},
  {src:'/photos/foto6.svg',caption:'Caption foto 6'},
]
export const letter = [
  'Hai, kamu.',
  'Sebenarnya aku bingung mau mulai dari mana.',
  'Aku membuat website kecil ini cuma untuk memberikan sesuatu yang berbeda buat kamu.',
  'Mungkin ini sederhana, tapi aku berharap website ini bisa membuat kamu tersenyum hari ini.',
  'Ada sesuatu yang sebenarnya ingin aku sampaikan, dan aku harap kamu membaca sampai selesai.',
]
export const sign = '— Someone ❤️'
export const fortunes = [
  'Hari ini kamu bakal dapat kabar baik. Percaya deh! ✨',
  'Ada senyum tak terduga yang menunggumu sebelum malam. 😊',
  'Makanan enak akan menemukanmu hari ini. 🍰',
  'Seseorang diam-diam mendoakan harimu berjalan indah. 💫',
  'Keberuntunganmu lagi naik 200%. Jangan ditolak! 🍀',
]
export const secret = 'Ada seseorang yang diam-diam senang kamu ada di dunia ini... 💭'
export const quiz = [
  {q:'Seberapa spesial kamu hari ini?',a:[['Spesial banget! 🌟',3],['Lumayan sih 😌',2],['Biasa aja… 🥲',1]]},
  {q:'Kalau jadi hewan, kamu paling mirip…',a:[['Kucing manja 🐱',3],['Kelinci lucu 🐰',3],['Panda ngantuk 🐼',2]]},
  {q:'Hal paling bikin kamu senyum?',a:[['Makanan enak 🍜',2],['Pesan dari orang baik 💬',3],['Tidur nyenyak 😴',2]]},
]
export const results = [
  [8,'Level Bintang Utama 🌟','Kamu spesial di atas rata-rata. Resmi!'],
  [6,'Level Permen Kapas 🍭','Manis, lembut, bikin hari orang cerah.'],
  [0,'Level Mutiara Tersembunyi 🐚','Spesialmu pelan-pelan terlihat, dan itu indah.'],
]
