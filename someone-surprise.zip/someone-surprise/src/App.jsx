import {useState,useEffect,useRef} from 'react'
import {photos,letter,sign,fortunes,secret,quiz,results} from './data.js'

let sfxCtx=null
const blip=(on)=>{if(!on)return;try{const AC=window.AudioContext||window.webkitAudioContext;sfxCtx=sfxCtx||new AC();const o=sfxCtx.createOscillator(),g=sfxCtx.createGain();o.frequency.value=880;g.gain.value=0.05;o.connect(g).connect(sfxCtx.destination);o.start();o.stop(sfxCtx.currentTime+0.08)}catch{}}

function useMusic(){
  const ctx=useRef(null),timer=useRef(null),[on,setOn]=useState(false)
  const notes=[523,659,784,659,587,698,880,698,494,587,784,587]
  const toggle=()=>{
    if(on){clearInterval(timer.current);setOn(false);return}
    const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return
    ctx.current=ctx.current||new AC();ctx.current.resume();let i=0
    const play=()=>{const c=ctx.current,o=c.createOscillator(),g=c.createGain();o.type='sine';o.frequency.value=notes[i++%notes.length]/2
      g.gain.setValueAtTime(0.001,c.currentTime);g.gain.exponentialRampToValueAtTime(0.08,c.currentTime+0.05);g.gain.exponentialRampToValueAtTime(0.001,c.currentTime+1.2)
      o.connect(g).connect(c.destination);o.start();o.stop(c.currentTime+1.3)}
    play();timer.current=setInterval(play,650);setOn(true)}
  useEffect(()=>()=>clearInterval(timer.current),[])
  return [on,toggle]
}

function Typer({text}){
  const [n,setN]=useState(0)
  useEffect(()=>{setN(0);const t=setInterval(()=>setN(x=>{if(x>=text.length){clearInterval(t);return x}return x+1}),45);return()=>clearInterval(t)},[text])
  return <p className="type">{text.slice(0,n)}<i>|</i></p>
}

function Welcome({go,sfx}){
  const [open,setOpen]=useState(false)
  const click=()=>{blip(sfx);setOpen(true);setTimeout(go,1100)}
  return <section className="screen center">
    <div className={'env '+(open?'open':'')}><div className="flap"/><div className="paper">💌</div><div className="body"/></div>
    <h1>Hai, kamu! 👀</h1><p>Iya, kamu yang lagi buka link ini.</p><p>Jangan kabur dulu, ada sesuatu buat kamu!</p>
    <button className="btn" onClick={click} disabled={open}>Buka Kejutan 💌</button>
  </section>
}

function Fun({go,sfx}){
  const [open,setOpen]=useState(null),[fortune,setFortune]=useState('')
  const pick=(i)=>{blip(sfx);setOpen(i);if(i===1)setFortune(fortunes[Math.floor(Math.random()*fortunes.length)])}
  const cards=['Klik kalau kamu imut 🐣','Baca ramalan hari ini 🔮','Ada yang mau aku bilang 🤫','Ambil bunga buat kamu 🌹']
  return <section className="screen">
    <h2>Pilih satu (atau semuanya) ✨</h2>
    <div className="grid">{cards.map((c,i)=><button key={i} className={'card glass '+(open===i?'on':'')} onClick={()=>pick(i)}>{c}</button>)}</div>
    <div className="glass panel" aria-live="polite">
      {open===null&&<p>Ketuk salah satu kartu di atas 👆</p>}
      {open===0&&<><div className="bounce">🐣</div><p>Sistem mendeteksi tingkat keimutan di atas rata-rata!</p></>}
      {open===1&&<><div className="bounce">🔮</div><p>{fortune}</p></>}
      {open===2&&<Typer text={secret}/>}
      {open===3&&<div className="bouquet"><div className="bounce big">🌹</div>{[...Array(12)].map((_,k)=><span key={k} className="petal" style={{'--x':(k*8+4)+'%','--d':(k%5)*0.4+'s'}}>🌸</span>)}<p>Bunga virtual ini khusus buat kamu 💐</p></div>}
    </div>
    <button className="btn" onClick={go}>Lanjut →</button>
  </section>
}

function Gallery({go,sfx}){
  const [caps,setCaps]=useState(photos.map(p=>p.caption)),[idx,setIdx]=useState(null),[play,setPlay]=useState(false),[bad,setBad]=useState({})
  useEffect(()=>{if(!play||idx===null)return;const t=setInterval(()=>setIdx(i=>(i+1)%photos.length),2800);return()=>clearInterval(t)},[play,idx])
  const Img=({i})=>bad[i]?<div className="ph">📷</div>:<img src={photos[i].src} alt={caps[i]} loading="lazy" onError={()=>setBad(b=>({...b,[i]:1}))}/>
  const close=()=>{setIdx(null);setPlay(false)}
  return <section className="screen">
    <h2>Kenangan kecil 📸</h2>
    <div className="scrap">{photos.map((_,i)=><button key={i} className="polaroid" style={{'--r':((i%3)-1)*4+'deg'}} onClick={()=>{blip(sfx);setIdx(i)}}><Img i={i}/><span>{caps[i]}</span></button>)}</div>
    <button className="btn" onClick={()=>{setIdx(0);setPlay(true)}}>▶ Slideshow</button>{' '}
    <button className="btn alt" onClick={go}>Lanjut →</button>
    {idx!==null&&<div className="lightbox" onClick={close}><div className="lb glass" onClick={e=>e.stopPropagation()}>
      <div className="lbimg" key={idx}><Img i={idx}/></div>
      <input aria-label="Edit caption" value={caps[idx]} onChange={e=>setCaps(c=>c.map((x,k)=>k===idx?e.target.value:x))}/>
      <div className="row"><button className="btn sm" onClick={()=>setIdx((idx+5)%6)}>←</button><button className="btn sm" onClick={()=>setPlay(p=>!p)}>{play?'⏸':'▶'}</button><button className="btn sm" onClick={()=>setIdx((idx+1)%6)}>→</button><button className="btn sm alt" onClick={close}>✕</button></div>
    </div></div>}
  </section>
}

function Quiz({go,sfx}){
  const [q,setQ]=useState(0),[score,setScore]=useState(0),[mys,setMys]=useState(null)
  const ans=(p)=>{blip(sfx);setScore(s=>s+p);setQ(q+1)}
  if(q<quiz.length)return <section className="screen center"><p className="tag">Pertanyaan {q+1}/{quiz.length}</p><h2>{quiz[q].q}</h2>
    {quiz[q].a.map(([t,p])=><button key={t} className="btn opt" onClick={()=>ans(p)}>{t}</button>)}</section>
  const r=results.find(x=>score>=x[0])
  return <section className="screen center"><div className="glass panel"><h2>{r[1]}</h2><p>{r[2]}</p><p className="tag">Skor: {score}</p></div>
    <h3>Kayaknya ada seseorang yang mau ngomong sesuatu. Mau tahu?</h3>
    {mys===null&&<><button className="btn" onClick={()=>setMys('y')}>Mau tahu dong! 😳</button><button className="btn alt" onClick={()=>setMys('n')}>Aku malu 🙈</button></>}
    {mys&&<><p className="glass panel">{mys==='y'?'Siap-siap ya, jantungnya dikuatkan dulu 💓':'Nggak apa-apa, pelan-pelan aja. Aku temenin kok 🤍'}</p><button className="btn" onClick={go}>Lanjut →</button></>}
  </section>
}

function Letter({go,sfx}){
  const [open,setOpen]=useState(false)
  return <section className="screen center">
    {!open&&<p>Ada surat untukmu. Ketuk amplopnya 👇</p>}
    <div className={'env small '+(open?'open':'')} onClick={()=>{blip(sfx);setOpen(true)}} role="button" tabIndex={0} onKeyDown={e=>e.key==='Enter'&&setOpen(true)}><div className="flap"/><div className="body"/></div>
    {open&&<><article className="letter glass">{letter.map((l,i)=><p key={i} style={{animationDelay:i*0.5+'s'}}>{l}</p>)}<p className="sig">{sign}</p></article><button className="btn" onClick={go}>Lanjut →</button></>}
  </section>
}

function Final({sfx}){
  const [a,setA]=useState(null)
  return <section className="screen center final">
    <h2>Okay, sekarang waktunya jujur sedikit... ❤️</h2>
    <p>Aku senang bisa mengenal kamu. Ada sesuatu dari dirimu yang membuatku ingin mengenalmu lebih dekat.</p>
    <p>Jadi, melalui website kecil ini, aku ingin menyampaikan sesuatu yang mungkin belum sempat aku katakan secara langsung.</p>
    <p className="big">Aku suka sama kamu.</p>
    <p>Kamu nggak harus menjawab sekarang. Aku hanya ingin jujur tentang perasaanku.</p>
    <h3>Boleh nggak aku mengenal kamu lebih dekat?</h3>
    {!a?<><button className="btn" onClick={()=>{blip(sfx);setA('y')}}>Boleh, ayo! 💗</button><button className="btn alt" onClick={()=>{blip(sfx);setA('n')}}>Aku pikir-pikir dulu, ya 🤍</button></>
    :<p className="glass panel">{a==='y'?'Makasih ya, kamu bikin harimu — dan hariku — jadi indah 💖 Aku akan hubungi kamu pelan-pelan.':'Tentu, nggak ada buru-buru. Makasih sudah baca sampai akhir. Apa pun jawabannya, aku tetap menghargaimu 🤍'}</p>}
    <p className="sig">— Someone ❤️</p>
  </section>
}

export default function App(){
  const [s,setS]=useState(0),[sfx,setSfx]=useState(false),[fx,setFx]=useState(true),[music,toggle]=useMusic()
  const go=()=>setS(x=>Math.min(x+1,5)),screens=[Welcome,Fun,Gallery,Quiz,Letter,Final],C=screens[s]
  return <div className={'app '+(fx?'':'nofx')+(s===5?' finalbg':'')}>
    <div className="bg" aria-hidden="true">{[...Array(14)].map((_,i)=><span key={i} style={{left:(i*7.3)%100+'%',animationDelay:(i%7)*-1.3+'s',fontSize:14+(i%4)*6}}>{['💗','🌸','✨','⭐','🤍'][i%5]}</span>)}</div>
    <header className="bar"><b>SOMEONE 💌</b><span>
      <button onClick={toggle} aria-label="Musik">{music?'⏸ 🎵':'▶ 🎵'}</button>
      <button onClick={()=>setSfx(!sfx)} aria-pressed={sfx} aria-label="Efek suara">{sfx?'🔊':'🔇'}</button>
      <button onClick={()=>setFx(!fx)} aria-pressed={fx} aria-label="Animasi dekoratif">{fx?'✨':'⛔'}</button></span></header>
    <main key={s} className="fade"><C go={go} sfx={sfx}/></main>
  </div>
}
