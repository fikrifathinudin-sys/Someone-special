# SOMEONE — A Little Surprise For You 💌
React + Vite, tanpa backend, tanpa menyimpan data pengunjung.

## Instalasi
```
npm install
npm run dev      # lihat di localhost
npm run build    # hasil di folder dist
```
## Mengganti foto
Taruh 6 foto kamu di `public/photos/` (mis. `foto1.jpg`), lalu ubah `src` di `src/data.js` → `photos`. Disarankan persegi, lebar ≤ 1000px, < 300 KB. Foto yang gagal dimuat otomatis tampil placeholder. Caption bisa diubah di `data.js` atau langsung di lightbox (sementara).
## Mengedit surat, ramalan, kuis
Semua ada di `src/data.js` (`letter`, `sign`, `fortunes`, `quiz`, `results`).
## Musik
Musik lembut dibuat dengan WebAudio, tidak autoplay. Tombol 🎵 = musik, 🔊 = efek suara, ✨ = animasi dekoratif.
## Deploy ke Vercel
Push ke GitHub → vercel.com → Import Project → Framework: Vite (build `npm run build`, output `dist`) → Deploy. Link publik langsung bisa dibuka siapa pun.
